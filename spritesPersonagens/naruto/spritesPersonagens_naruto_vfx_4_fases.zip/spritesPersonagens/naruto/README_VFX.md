# Pacote de VFXs Isolados — Naruto Uzumaki (4 Fases de Evolução)

Estrutura compatível 1:1 com `spritesPersonagens/naruto/`:

```text
spritesPersonagens/
└── naruto/
    ├── README_VFX.md
    ├── manifest_vfx.json
    ├── fase1_lvl0-5_normal/
    │   ├── sheets_2x2_raw/          # 4 folhas 2x2 de VFX (fundo #FF00FF)
    │   └── frames_transparent_png/  # 16 quadros de VFX recortados (Q1..Q4) em PNG transparente
    ├── fase2_lvl6-10_quatro_caudas/
    │   ├── sheets_2x2_raw/
    │   └── frames_transparent_png/
    ├── fase3_lvl11-15_manto_kurama/
    │   ├── sheets_2x2_raw/
    │   └── frames_transparent_png/
    └── fase4_lvl16_modo_barion/
        ├── sheets_2x2_raw/
        └── frames_transparent_png/
```

## VFXs por Fase (4 Golpes × 4 Quadros = 16 frames por fase)
- `vfx_attack1_soco_combo`: Efeitos de carga, impacto direto, arco de gancho e explosão de uppercut.
- `vfx_attack2_chute_investida`: Impulso de avanço, rastro de investida, lâmina de chute giratório e impacto no solo.
- `vfx_attack3_projetil_energia`: Projétil isolado em 4 estágios (ignição, voo, velocidade máxima e impacto).
- `vfx_attack4_ultimate_especial`: Golpe Especial / Ultimate isolado em 4 estágios (núcleo, expansão, propulsão e detonação).
