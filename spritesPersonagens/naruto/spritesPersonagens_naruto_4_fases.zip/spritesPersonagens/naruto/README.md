# Pacote de Sprites — Naruto Uzumaki (4 Fases de Evolução)

Estrutura de diretórios padronizada para motor de jogo 2D (Phaser 3 / TypeScript / Vite):

```text
spritesPersonagens/
└── naruto/
    ├── README.md
    ├── manifest.json
    ├── scripts/
    │   └── processSprites.py
    ├── fase1_lvl0-5_normal/
    │   ├── sheets_2x2_raw/          # 10 folhas 2x2 originais (16:9, fundo #FF00FF)
    │   └── frames_transparent_png/  # 40 quadros recortados (Q1..Q4) em PNG transparente
    ├── fase2_lvl6-10_quatro_caudas/
    │   ├── sheets_2x2_raw/
    │   └── frames_transparent_png/
    ├── fase3_lvl11-15_manto_kurama/
    │   ├── sheets_2x2_raw/
    │   └── frames_transparent_png/
    └── fase4_lvl16_modo_barion/
        ├── sheets_2x2_raw/
        └── frames_transparent_png/
```

## Animações Incluídas em Cada Fase (10 folhas = 40 frames por fase)
1. `idle` — Pose de guarda e respiração (4 frames)
2. `attack1_soco_combo` — Ataque 1: Soco / Combo básico (4 frames)
3. `attack2_chute_investida` — Ataque 2: Chute / Investida (4 frames)
4. `attack3_projetil_energia` — Ataque 3: Projétil de energia / Alcance longo (4 frames)
5. `attack4_ultimate_especial` — Ataque 4: Golpe Especial / Ultimate (4 frames)
6. `run_dash` — Corrida ninja / Dash (4 frames)
7. `jump` — Salto completo (4 frames)
8. `crouch` — Agachar / Guarda baixa (4 frames)
9. `block` — Defesa / Bloqueio (4 frames)
10. `hitstun` — Recebendo dano / Recuo (4 frames)
