#!/usr/bin/env python3
"""
Script utilitário para recortar folhas 2x2 e remover fundo Magenta (#FF00FF).
Uso: python3 scripts/processSprites.py
"""
import os
from pathlib import Path
import numpy as np
from PIL import Image

def remove_magenta(img: Image.Image) -> Image.Image:
    rgba = np.array(img.convert("RGBA"), dtype=np.int16)
    r, g, b = rgba[:, :, 0], rgba[:, :, 1], rgba[:, :, 2]
    magenta_ness = np.minimum(r, b) - g
    diff_rb = np.abs(r - b)
    mask_bg = (magenta_ness > 115) & (diff_rb < 65) & (g < 110)
    rgba[mask_bg, 3] = 0
    return Image.fromarray(rgba.astype(np.uint8), "RGBA")

if __name__ == "__main__":
    print("Pronto para reprocessar folhas 2x2 em spritesPersonagens/naruto/")
