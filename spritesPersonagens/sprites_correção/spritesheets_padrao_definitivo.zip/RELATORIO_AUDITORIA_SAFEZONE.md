# Relatório de Auditoria Técnica — Padrão Definitivo de Sprite Sheets

Todas as sprite sheets foram processadas e auditadas segundo a **Seção 3 — Padrão Técnico Definitivo**:
- **Células**: `512 × 512 px` exatos (`1536×1024` para `3×2`, `2048×1024` para `4×2`, `2048×1536` para `4×3`).
- **Safe Zone Cumprida em 100% dos Frames**: Topo `>= 92 px` (18%), Esquerda/Direita `>= 77 px` (15%), Base `>= 52 px` (>10%).
- **Baseline e Pivô**: Pés ancorados exatamente em `y = 460 px` e centro de massa alinhado ao eixo `x = 256 px`.
- **Fundo Chroma-Key**: 100% `#FF00FF` (`RGB 255, 0, 255`) puro, sem linhas de grade, vinhetas ou sombras.

| Arquivo no Pacote | Grid | Resolução | Margem Topo (mín) | Margem Esq (mín) | Margem Dir (mín) | Margem Base | Baseline Y | Status |
|---|---|---|---|---|---|---|---|---|
| `spritesPersonagens/overrides/goku/fase_2_super_saiyajin/run_3x2.png` | `3x2` | `1536x1024` | `100 px` | `89 px` | `113 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/goku/fase_2_super_saiyajin/ataque_4_3x2.png` | `3x2` | `1536x1024` | `105 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/goku/fase_3_super_saiyajin_3/idle_3x2.png` | `3x2` | `1536x1024` | `120 px` | `129 px` | `124 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/goku/fase_3_super_saiyajin_3/crouch_3x2.png` | `3x2` | `1536x1024` | `200 px` | `140 px` | `143 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/goku/fase_3_super_saiyajin_3/hitstun_3x2.png` | `3x2` | `1536x1024` | `130 px` | `95 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/goku/fase_4_instinto_superior/ataque_3_3x2.png` | `3x2` | `1536x1024` | `100 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/chopper/fase_2_heavy_point/idle_3x2.png` | `3x2` | `1536x1024` | `110 px` | `110 px` | `102 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/chopper/fase_2_heavy_point/block_3x2.png` | `3x2` | `1536x1024` | `110 px` | `131 px` | `113 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/chopper/fase_2_heavy_point/ataque_1_3x2.png` | `3x2` | `1536x1024` | `110 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/chopper/fase_2_heavy_point/ataque_2_3x2.png` | `3x2` | `1536x1024` | `110 px` | `80 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/chopper/fase_2_heavy_point/ataque_3_3x2.png` | `3x2` | `1536x1024` | `110 px` | `109 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/chopper/fase_2_heavy_point/ataque_4_3x2.png` | `3x2` | `1536x1024` | `110 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/chopper/fase_4_monster_point/ataque_4_3x2.png` | `3x2` | `1536x1024` | `110 px` | `78 px` | `83 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_1_classico/idle_3x2.png` | `3x2` | `1536x1024` | `100 px` | `118 px` | `136 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_1_classico/run_3x2.png` | `3x2` | `1536x1024` | `119 px` | `77 px` | `107 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_1_classico/ataque_4_3x2.png` | `3x2` | `1536x1024` | `110 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_1_classico/land_3x2.png` | `3x2` | `1536x1024` | `110 px` | `126 px` | `113 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_1_classico/dash_3x2.png` | `3x2` | `1536x1024` | `110 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_1_classico/knockdown_3x2.png` | `3x2` | `1536x1024` | `134 px` | `85 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_1_classico/victory_3x2.png` | `3x2` | `1536x1024` | `100 px` | `143 px` | `128 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_2_shippuden/idle_3x2.png` | `3x2` | `1536x1024` | `100 px` | `133 px` | `135 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_2_shippuden/ataque_4_3x2.png` | `3x2` | `1536x1024` | `110 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_3_modo_sennin/idle_3x2.png` | `3x2` | `1536x1024` | `100 px` | `115 px` | `84 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_3_modo_sennin/ataque_4_3x2.png` | `3x2` | `1536x1024` | `120 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_4_modo_kurama/idle_3x2.png` | `3x2` | `1536x1024` | `100 px` | `83 px` | `107 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/overrides/naruto/fase_4_modo_kurama/ataque_4_3x2.png` | `3x2` | `1536x1024` | `110 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/expansoes_secao_2/goku/fase_2_super_saiyajin/land_3x2.png` | `3x2` | `1536x1024` | `100 px` | `103 px` | `128 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/expansoes_secao_2/goku/fase_2_super_saiyajin/dash_3x2.png` | `3x2` | `1536x1024` | `110 px` | `77 px` | `80 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/expansoes_secao_2/goku/fase_2_super_saiyajin/knockdown_3x2.png` | `3x2` | `1536x1024` | `120 px` | `77 px` | `77 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/expansoes_secao_2/goku/fase_2_super_saiyajin/victory_3x2.png` | `3x2` | `1536x1024` | `100 px` | `126 px` | `109 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/expansoes_secao_2/goku/fase_2_super_saiyajin/run_4x2.png` | `4x2` | `2048x1024` | `109 px` | `110 px` | `148 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/expansoes_secao_2/goku/fase_2_super_saiyajin/ataque_4_4x3.png` | `4x3` | `2048x1536` | `152 px` | `117 px` | `109 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/expansoes_secao_2/luffy/fase_1_base/ataque_1_4x2.png` | `4x2` | `2048x1024` | `110 px` | `100 px` | `99 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
| `spritesPersonagens/expansoes_secao_2/zoro/fase_1_base/ataque_1_4x2.png` | `4x2` | `2048x1024` | `143 px` | `94 px` | `80 px` | `52 px` | `y=460px` | **APROVADO (100%)** |
